"""
Database connection and query helper functions.
Uses psycopg2 to talk to PostgreSQL.
"""

import psycopg2
import psycopg2.extras
import config


def get_connection():
    """Open a new connection to the PostgreSQL database."""
    return psycopg2.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        dbname=config.DB_NAME,
        user=config.DB_USER,
        password=config.DB_PASSWORD
    )


def run_query(query, params=None, fetch=False, fetch_one=False):
    """
    Generic query runner.
    - fetch=True returns all rows as list of dicts
    - fetch_one=True returns a single row as dict
    - Otherwise, executes and commits (INSERT/UPDATE/DELETE)
    """
    conn = get_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    result = None
    try:
        cur.execute(query, params or ())
        if fetch:
            result = cur.fetchall()
        elif fetch_one:
            result = cur.fetchone()
        else:
            conn.commit()
            try:
                result = cur.fetchone()
            except psycopg2.ProgrammingError:
                result = None
    finally:
        cur.close()
        conn.close()
    return result


# ---------- Customer-facing queries ----------

def create_customer_if_not_exists(name, phone, address):
    existing = run_query(
        "SELECT customer_id FROM customers WHERE phone = %s",
        (phone,), fetch_one=True
    )
    if existing:
        return existing["customer_id"]

    row = run_query(
        """INSERT INTO customers (name, phone, address)
           VALUES (%s, %s, %s) RETURNING customer_id""",
        (name, phone, address)
    )
    return row["customer_id"]


def create_appointment(customer_id, grain_type, qty, requested_date, preferred_slot):
    row = run_query(
        """INSERT INTO appointments
           (customer_id, grain_type, requested_qty_kg, requested_date, preferred_time_slot)
           VALUES (%s, %s, %s, %s, %s) RETURNING appointment_id""",
        (customer_id, grain_type, qty, requested_date, preferred_slot)
    )
    return row["appointment_id"]


def get_appointment_status(appointment_id):
    return run_query(
        """SELECT a.appointment_id, a.status, a.assigned_slot_time,
                  a.grain_type, a.requested_qty_kg, c.name, c.phone
           FROM appointments a
           JOIN customers c ON c.customer_id = a.customer_id
           WHERE a.appointment_id = %s""",
        (appointment_id,), fetch_one=True
    )


# ---------- Owner dashboard queries ----------

def get_appointments_by_status(status):
    return run_query(
        """SELECT a.appointment_id, c.name, c.phone, a.grain_type,
                  a.requested_qty_kg, a.requested_date, a.preferred_time_slot,
                  a.assigned_slot_time, a.status
           FROM appointments a
           JOIN customers c ON c.customer_id = a.customer_id
           WHERE a.status = %s
           ORDER BY a.requested_date, a.created_at""",
        (status,), fetch=True
    )


def assign_slot(appointment_id, slot_datetime):
    run_query(
        """UPDATE appointments
           SET assigned_slot_time = %s, status = 'assigned'
           WHERE appointment_id = %s""",
        (slot_datetime, appointment_id)
    )


def start_milling(appointment_id, machine_id):
    row = run_query(
        """INSERT INTO milling_jobs (appointment_id, start_time, machine_id)
           VALUES (%s, NOW(), %s) RETURNING job_id""",
        (appointment_id, machine_id)
    )
    return row["job_id"]


def complete_milling(job_id, output_qty, wastage_qty):
    run_query(
        """UPDATE milling_jobs
           SET end_time = NOW(), output_qty_kg = %s, wastage_qty_kg = %s
           WHERE job_id = %s""",
        (output_qty, wastage_qty, job_id)
    )


def complete_appointment_and_bill(appointment_id, amount_charged, payment_status):
    run_query(
        "UPDATE appointments SET status = 'completed' WHERE appointment_id = %s",
        (appointment_id,)
    )
    row = run_query(
        """INSERT INTO orders (appointment_id, amount_charged, payment_status)
           VALUES (%s, %s, %s) RETURNING order_id""",
        (appointment_id, amount_charged, payment_status)
    )
    return row["order_id"]


def get_milling_job_for_appointment(appointment_id):
    return run_query(
        """SELECT * FROM milling_jobs WHERE appointment_id = %s
           ORDER BY job_id DESC LIMIT 1""",
        (appointment_id,), fetch_one=True
    )


def get_dashboard_summary():
    return run_query(
        """SELECT
             COUNT(*) FILTER (WHERE status = 'pending')   AS pending_count,
             COUNT(*) FILTER (WHERE status = 'assigned')  AS assigned_count,
             COUNT(*) FILTER (WHERE status = 'completed') AS completed_count
           FROM appointments""",
        fetch_one=True
    )
