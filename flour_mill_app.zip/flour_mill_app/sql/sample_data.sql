-- Optional: sample data for demo/testing before you have real usage

INSERT INTO customers (name, phone, address) VALUES
('Ramesh Kumar', '9900011111', 'Davanagere'),
('Sunita Patil', '9900022222', 'Harihar'),
('Manjunath G', '9900033333', 'Davanagere'),
('Lakshmi Devi', '9900044444', 'Channagiri');

INSERT INTO appointments (customer_id, grain_type, requested_qty_kg, requested_date, preferred_time_slot, status) VALUES
(1, 'wheat', 10, CURRENT_DATE, 'morning', 'pending'),
(2, 'ragi', 5, CURRENT_DATE, 'evening', 'pending'),
(3, 'rice', 20, CURRENT_DATE - INTERVAL '1 day', 'afternoon', 'completed'),
(4, 'jowar', 8, CURRENT_DATE - INTERVAL '1 day', 'morning', 'completed');

-- give the completed ones a milling job + order so Power BI has data to show
INSERT INTO milling_jobs (appointment_id, start_time, end_time, output_qty_kg, wastage_qty_kg, machine_id) VALUES
(3, NOW() - INTERVAL '1 day 2 hours', NOW() - INTERVAL '1 day 1 hour', 19.2, 0.8, 'M1'),
(4, NOW() - INTERVAL '1 day 3 hours', NOW() - INTERVAL '1 day 2 hours', 7.6, 0.4, 'M1');

INSERT INTO orders (appointment_id, amount_charged, payment_status, order_date) VALUES
(3, 200, 'paid', CURRENT_DATE - INTERVAL '1 day'),
(4, 90, 'paid', CURRENT_DATE - INTERVAL '1 day');
