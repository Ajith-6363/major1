-- ============================================
-- Flour Mill Management System - Schema
-- ============================================

CREATE TABLE customers (
    customer_id     SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    phone           VARCHAR(15) NOT NULL UNIQUE,
    address         VARCHAR(255),
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE TABLE appointments (
    appointment_id      SERIAL PRIMARY KEY,
    customer_id         INTEGER NOT NULL REFERENCES customers(customer_id),
    grain_type          VARCHAR(50) NOT NULL,          -- wheat, ragi, rice, jowar etc.
    requested_qty_kg    NUMERIC(6,2) NOT NULL CHECK (requested_qty_kg > 0),
    requested_date      DATE NOT NULL,
    preferred_time_slot VARCHAR(20),                    -- e.g. "morning", "evening" (customer's ask)
    assigned_slot_time  TIMESTAMP,                       -- owner fills this in
    status              VARCHAR(20) NOT NULL DEFAULT 'pending'
                         CHECK (status IN ('pending','assigned','completed','cancelled')),
    created_at          TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_appointments_customer ON appointments(customer_id);
CREATE INDEX idx_appointments_status   ON appointments(status);
CREATE INDEX idx_appointments_date     ON appointments(requested_date);

CREATE TABLE milling_jobs (
    job_id          SERIAL PRIMARY KEY,
    appointment_id  INTEGER NOT NULL REFERENCES appointments(appointment_id),
    start_time      TIMESTAMP,
    end_time        TIMESTAMP,
    output_qty_kg   NUMERIC(6,2),
    wastage_qty_kg  NUMERIC(6,2) DEFAULT 0,
    machine_id      VARCHAR(20) DEFAULT 'M1',
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_milling_appointment ON milling_jobs(appointment_id);

CREATE TABLE orders (
    order_id            SERIAL PRIMARY KEY,
    appointment_id      INTEGER NOT NULL REFERENCES appointments(appointment_id),
    amount_charged      NUMERIC(8,2) NOT NULL DEFAULT 0,
    payment_status      VARCHAR(20) NOT NULL DEFAULT 'unpaid'
                         CHECK (payment_status IN ('unpaid','paid','partial')),
    order_date          DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at          TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_orders_appointment ON orders(appointment_id);
CREATE INDEX idx_orders_date        ON orders(order_date);

-- Daily rollup table — can be populated by a Python script (nightly job)
-- or built as a Power BI measure directly from the tables above.
-- Kept here as an optional physical table if you want faster BI queries.
CREATE TABLE daily_operations (
    op_date                 DATE PRIMARY KEY,
    total_customers_served  INTEGER DEFAULT 0,
    total_qty_milled_kg     NUMERIC(8,2) DEFAULT 0,
    total_revenue           NUMERIC(10,2) DEFAULT 0,
    total_wastage_kg        NUMERIC(8,2) DEFAULT 0,
    machine_downtime_min    INTEGER DEFAULT 0
);
