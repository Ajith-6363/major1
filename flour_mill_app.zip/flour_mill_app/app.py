from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime
from functools import wraps
import config
from models import db

app = Flask(__name__)
app.secret_key = config.SECRET_KEY


# ---------- Auth helper ----------

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("owner_login"))
        return f(*args, **kwargs)
    return wrapper


# ---------- Public / customer-facing routes ----------

@app.route("/")
def home():
    return render_template("home.html")


@app.route("/request", methods=["GET", "POST"])
def customer_request():
    if request.method == "POST":
        name = request.form["name"]
        phone = request.form["phone"]
        address = request.form.get("address", "")
        grain_type = request.form["grain_type"]
        qty = request.form["qty"]
        requested_date = request.form["requested_date"]
        preferred_slot = request.form.get("preferred_slot", "")

        customer_id = db.create_customer_if_not_exists(name, phone, address)
        appointment_id = db.create_appointment(
            customer_id, grain_type, qty, requested_date, preferred_slot
        )

        flash(f"Request submitted! Your appointment ID is {appointment_id}. "
              f"Save this to check your status.")
        return redirect(url_for("check_status", appointment_id=appointment_id))

    return render_template("customer_request.html")


@app.route("/status/<int:appointment_id>")
def check_status(appointment_id):
    appointment = db.get_appointment_status(appointment_id)
    if not appointment:
        flash("No appointment found with that ID.")
        return redirect(url_for("home"))
    return render_template("order_status.html", appt=appointment)


# ---------- Owner login ----------

@app.route("/owner/login", methods=["GET", "POST"])
def owner_login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username == config.OWNER_USERNAME and password == config.OWNER_PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("owner_dashboard"))
        flash("Invalid credentials.")
    return render_template("owner_login.html")


@app.route("/owner/logout")
def owner_logout():
    session.pop("logged_in", None)
    return redirect(url_for("owner_login"))


# ---------- Owner dashboard ----------

@app.route("/owner/dashboard")
@login_required
def owner_dashboard():
    pending = db.get_appointments_by_status("pending")
    assigned = db.get_appointments_by_status("assigned")
    completed = db.get_appointments_by_status("completed")
    summary = db.get_dashboard_summary()
    return render_template(
        "owner_dashboard.html",
        pending=pending, assigned=assigned, completed=completed, summary=summary
    )


@app.route("/owner/assign/<int:appointment_id>", methods=["POST"])
@login_required
def owner_assign(appointment_id):
    slot_time = request.form["slot_time"]  # datetime-local input
    db.assign_slot(appointment_id, slot_time)
    flash(f"Slot assigned for appointment {appointment_id}.")
    return redirect(url_for("owner_dashboard"))


@app.route("/owner/start_milling/<int:appointment_id>", methods=["POST"])
@login_required
def owner_start_milling(appointment_id):
    machine_id = request.form.get("machine_id", "M1")
    db.start_milling(appointment_id, machine_id)
    flash(f"Milling started for appointment {appointment_id}.")
    return redirect(url_for("owner_dashboard"))


@app.route("/owner/complete/<int:appointment_id>", methods=["POST"])
@login_required
def owner_complete(appointment_id):
    output_qty = request.form["output_qty"]
    wastage_qty = request.form.get("wastage_qty", 0)
    amount_charged = request.form["amount_charged"]
    payment_status = request.form.get("payment_status", "unpaid")

    job = db.get_milling_job_for_appointment(appointment_id)
    if job:
        db.complete_milling(job["job_id"], output_qty, wastage_qty)

    db.complete_appointment_and_bill(appointment_id, amount_charged, payment_status)
    flash(f"Appointment {appointment_id} marked completed and billed.")
    return redirect(url_for("owner_dashboard"))


if __name__ == "__main__":
    app.run(debug=True)
