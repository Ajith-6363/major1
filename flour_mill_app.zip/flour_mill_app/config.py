# ============================================
# Configuration
# ============================================

# --- PostgreSQL connection settings ---
DB_HOST = "localhost"
DB_PORT = "5432"
DB_NAME = "flour_mill_db"
DB_USER = "postgres"
DB_PASSWORD = "your_postgres_password"   # change this

# --- Owner dashboard login ---
OWNER_USERNAME = "owner"
OWNER_PASSWORD = "mill123"               # change this before submitting/demo

# --- Flask secret key (for session handling) ---
SECRET_KEY = "change_this_to_something_random"
