# Flour Mill Management App + Power BI Dashboard

A simple industry-style system for a flour mill:
Customer -> Appointment/Queue -> Milling -> Order Status -> Daily Sales/Operations -> Power BI Dashboard

Stack: PostgreSQL + Python (Flask) + Power BI. No ML.

---

## 1. Prerequisites

- Python 3.9+ installed
- PostgreSQL + pgAdmin installed
- Power BI Desktop installed (Windows) — for the dashboard step later

---

## 2. Set up the database

1. Open **pgAdmin**, connect to your local PostgreSQL server.
2. Create a new database called `flour_mill_db`.
3. Open the **Query Tool** on that database.
4. Open `sql/schema.sql` from this project, paste its contents into the Query Tool, and run it (F5). This creates all tables.
5. (Optional but recommended for your first demo) Run `sql/sample_data.sql` the same way — this gives you a few customers, appointments, a completed job and an order so your dashboard has something to show immediately.

---

## 3. Set up the Python app

Open a terminal in the project folder (`flour_mill_app/`) and run:

```bash
# create a virtual environment (recommended)
python -m venv venv

# activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# install dependencies
pip install -r requirements.txt
```

---

## 4. Configure your database credentials

Open `config.py` and edit these lines to match your PostgreSQL setup:

```python
DB_HOST = "localhost"
DB_PORT = "5432"
DB_NAME = "flour_mill_db"
DB_USER = "postgres"
DB_PASSWORD = "your_postgres_password"   # <-- put your real password here
```

Also feel free to change the owner login and secret key:

```python
OWNER_USERNAME = "owner"
OWNER_PASSWORD = "mill123"
SECRET_KEY = "change_this_to_something_random"
```

---

## 5. Run the app

```bash
python app.py
```

You should see something like:
```
* Running on http://127.0.0.1:5000
```

Open that URL in your browser.

- **Customer flow:** Home -> "Request a Slot" -> fill form -> get an Appointment ID -> check status anytime at `/status/<id>`.
- **Owner flow:** Home -> "Owner Login" -> log in with the username/password from `config.py` -> see Pending / Assigned / Completed tables -> assign slots, start milling, complete + bill.

Try the full cycle once yourself: submit a request as a customer, then log in as the owner and move it from pending -> assigned -> completed. This is what you'll demo live.

---

## 6. Connect Power BI

1. Open **Power BI Desktop**.
2. **Get Data** -> search "PostgreSQL database".
3. Enter:
   - Server: `localhost:5432` (or `localhost` with port 5432 in the separate field, depending on your Power BI version)
   - Database: `flour_mill_db`
4. Choose **Import** mode (simpler for a project demo).
5. Log in with your PostgreSQL username/password.
6. Select these tables and load them:
   - `customers`
   - `appointments`
   - `milling_jobs`
   - `orders`
7. In Power BI, go to **Model view** and set up relationships if they aren't auto-detected:
   - `customers.customer_id` -> `appointments.customer_id`
   - `appointments.appointment_id` -> `milling_jobs.appointment_id`
   - `appointments.appointment_id` -> `orders.appointment_id`

### Suggested visuals for your dashboard
- **Card visuals:** Total Revenue (sum of `orders.amount_charged`), Total Customers, Total Qty Milled
- **Bar chart:** Revenue by grain type (`appointments.grain_type` vs sum of `orders.amount_charged`)
- **Line chart:** Daily revenue trend (`orders.order_date` vs sum of `amount_charged`)
- **Pie/Donut chart:** Appointment status breakdown (`appointments.status`)
- **Table:** Pending appointments needing action
- **Card/gauge:** Wastage % = sum(wastage_qty_kg) / sum(output_qty_kg + wastage_qty_kg)

Refresh the dashboard (Home -> Refresh) any time after using the app to see updated numbers — this is your "daily business update" story for the report/demo.

---

## 7. Project structure

```
flour_mill_app/
├── app.py                  # Flask routes
├── config.py                # DB + login config
├── models/
│   └── db.py                 # All DB queries
├── templates/                # HTML pages
├── static/
│   └── style.css
├── sql/
│   ├── schema.sql            # Run this first
│   └── sample_data.sql       # Optional demo data
└── requirements.txt
```

---

## 8. Ideas for your project report (talking points)

- **Modules:** Customer Module, Appointment/Queue Module, Milling Module, Billing Module, Owner Dashboard, BI Reporting Module.
- **Why separate `milling_jobs` and `orders` tables:** mirrors real ERP systems where production and billing are tracked independently — lets you discuss "normalization" and "separation of concerns" in your viva.
- **Why Power BI connects directly to PostgreSQL:** avoids duplicate reporting logic in Python; single source of truth.
- **Possible future scope (mention in report as "future enhancements"):** SMS/WhatsApp slot confirmation, multi-machine load balancing, customer login/history, automated daily rollup job into `daily_operations` table.
